# Value for the default dialect to be used as a part of
# Search or Aggregate query.
DEFAULT_DIALECT = 2
